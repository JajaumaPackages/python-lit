# Check the env command
#
# RUN: %{lit} -a -v %{inputs}/shtest-env
